// src/main/java/com/example/yourapp/MainActivity.kt
package com.example.weather

import android.os.AsyncTask
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONException
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    private lateinit var editTextLat: EditText
    private lateinit var editTextLon: EditText
    private lateinit var textViewResult: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextLat = findViewById(R.id.editTextLat)
        editTextLon = findViewById(R.id.editTextLon)
        textViewResult = findViewById(R.id.textViewResult)

        val buttonGetWeather: Button = findViewById(R.id.buttonGetWeather)
        buttonGetWeather.setOnClickListener {
            val lat = editTextLat.text.toString()
            val lon = editTextLon.text.toString()
            GetWeatherTask().execute(lat, lon)
        }
    }

    private inner class GetWeatherTask : AsyncTask<String, Void, String>() {

        override fun doInBackground(vararg params: String): String? {
            val lat = params[0]
            val lon = params[1]
            val apiKey = getString(R.string.openweather_api_key)
            val apiUrl = "https://api.openweathermap.org/data/3.0/onecall?lat=$lat&lon=$lon&exclude=current&appid=$apiKey"

            return try {
                val url = URL(apiUrl)
                val urlConnection = url.openConnection() as HttpURLConnection
                try {
                    val bufferedReader = BufferedReader(InputStreamReader(urlConnection.inputStream))
                    val stringBuilder = StringBuilder()
                    var line: String?
                    while (bufferedReader.readLine().also { line = it } != null) {
                        stringBuilder.append(line).append("\n")
                    }
                    bufferedReader.close()
                    stringBuilder.toString()
                } finally {
                    urlConnection.disconnect()
                }
            } catch (e: IOException) {
                null
            }
        }

        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)
            if (result != null) {
                try {
                    val json = JSONObject(result)
                    // TODO: 解析 JSON，顯示目前溫度
                    // 例如: val temperature = json.getJSONObject("current").getDouble("temp")
                    //      textViewResult.text = "Current Temperature: $temperature°C"
                    // 擷取目前的氣象資訊
                    val currentWeather = json.getJSONObject("current")
                    val temperature = currentWeather.getDouble("temp")
                    val feelsLike = currentWeather.getDouble("feels_like")
                    val humidity = currentWeather.getInt("humidity")
                    val weatherArray = currentWeather.getJSONArray("weather")
                    val weatherMain = weatherArray.getJSONObject(0).getString("main")

                    // TODO: 將擷取的資訊顯示在使用者介面中
                    val displayText = "Temperature: $temperature°C\nFeels Like: $feelsLike°C\nHumidity: $humidity%\nWeather: $weatherMain"
                    textViewResult.text = displayText
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            } else {
                textViewResult.text = "Error fetching weather data."
            }
        }
    }
}